package com.assign;

public class LowerCase {
	public static void main(String[] args) {
		String str = "THE QUICK BROWn FOX!";
		String lower_str = str.toLowerCase();
		System.out.println("Original String: " + str);
		System.out.println("String in Lower Case: " + lower_str);
	}
}
